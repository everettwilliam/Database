

CREATE TABLE Artist (
     AName  varchar2(20) NOT NULL,
     Birthplace  varchar2(20),
     Style  varchar2(20),
     DateofBirth  date,
    country character varying(20)
);

CREATE TABLE Artwork (
     Title  varchar2(20) NOT NULL,
     Year  integer,
     Type  varchar2(20),
     Price  numeric(8,2),
     AName  varchar2(20)
);


CREATE TABLE Customer (
     CustId  integer NOT NULL,
     Name  varchar2(20),
     Address  varchar2(20),
     Amount  numeric(8,2),
    rating integer,
    CONSTRAINT  Customer_rating_check  CHECK (((rating >= 1) AND (rating <= 10)))
);

CREATE TABLE LikeArtist (
     CustId  integer NOT NULL,
     AName  varchar2(20) NOT NULL
);


insert into Customer
values(1,'Emre','Preston',20000.00,5);
insert into Customer
values(2,'Saeid',null, 40000.00,6);

--Select * from  Customer ;

insert into Artwork
values('Waves',2000,null, 4000.00,'John');
insert into Artwork
values('Three Musicians',1921,'Modern', 11000.00,'Picasso');

--Select * from Artwork;

insert into Artist
values ('Leonardo','Florence','Renaissance','05-May-1452','Italy');
insert into Artist
values('Michelangelo','Arezzo','Renaissance','03-June-1475','Italy');
insert into Artist
values('Josefa','Seville','Baroque','09-Sep-1630','Spain');
insert into Artist
values('Hans Hofmann','Weisenburg','Modern','02-May-1966','Germany');
insert into Artist
values('John','San Francisco', 'Modern','02-May-1920','USA');

--Select * from Artist;

insert into LikeArtist
values (1, 'Picasso');
insert into LikeArtist
values (2, 'Picasso');
insert into LikeArtist
values (1, 'Leonardo');

--Select * from LikeArtist;


