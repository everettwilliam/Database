-- We have partitioned the sales in a year into three periods.


CREATE TABLE sales
  ( title_ids       NUMBER(6)
  , time_id       DATE
  , quantity_sold NUMBER(3)
  )
 PARTITION BY RANGE (time_id)
 ( PARTITION sales_p1_2015 VALUES LESS THAN (TO_DATE('01-MAY-2015','dd-MON-yyyy'))
    TABLESPACE lab9a
 , PARTITION sales_p2_2015 VALUES LESS THAN (TO_DATE('01-SEP-2015','dd-MON-yyyy'))
    TABLESPACE lab9b
 , PARTITION sales_p3_2015 VALUES LESS THAN (TO_DATE('01-JAN-2016','dd-MON-yyyy'))
    TABLESPACE lab9c
 );


-- you may have to change the format of the date.

insert into sales
 values (1, '15-10-12',20);
 
 insert into sales
 values (2, '15-9-12',50);
 
 insert into sales
 values (3, '15-01-12',13);
 
 insert into sales
 values (4, '15-6-05',100);
 
 insert into sales
 values (5, '15-02-26',10);