CREATE TABLE sales01
  ( prod_id       NUMBER(6)
  , time_id       DATE
  , quantity_sold NUMBER(3)
  )
 PARTITION BY RANGE (quantity_sold)
 ( PARTITION sales_p1 VALUES LESS THAN (35)
    TABLESPACE lab9a
 , PARTITION sales_p2 VALUES LESS THAN (76)
    TABLESPACE lab9b
 , PARTITION sales_p3 VALUES LESS THAN (MAXVALUE)
    TABLESPACE lab9c
 );

insert into sales01
 values (1, '15-10-12',20);
 
 insert into sales01
 values (2, '15-9-12',50);
 
 insert into sales01
 values (3, '15-01-12',13);
 
 insert into sales01
 values (4, '15-6-05',100);
 
 insert into sales01
 values (5, '15-02-26',10);